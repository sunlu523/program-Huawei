$(function(){
$('li').mouseover(function () {
    var index = $(this).index();
    $('div').eq(index).show().siblings('div').hide();
});
$('nav').mouseleave(function () {
    $('div').hide();
});

});
